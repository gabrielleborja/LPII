package br.ufrn.imd.modelo;

public interface ICarbonFootPrint {

	double getCarbonFootprint();
}
